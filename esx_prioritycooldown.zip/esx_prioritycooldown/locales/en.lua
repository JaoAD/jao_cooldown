Locales['en'] = {
    ['not_allowed'] = "You are not a police officer!" ,
    ['set_safe'] = " set the priority status to **safe**." , 
    ['set_cooldown'] = " set the priority status to **cooldown**." ,
    ['set_ongoing'] = " set the priority status to **in progress**." ,
    ['set_reset'] = " set the priority status to **reset to 0**." ,
    ['crime_ongoing'] = "Crime: ~b~In Progress",
    ['crime_safe'] = "Crime: ~g~Safe",
    ['crime_cooldown'] = "Crime: ~r~%s ~w~mins",
    ['safe_clear'] = "^8^*SAFE & CLEAR: ^r^7City is safe for a moment, any crimes and robbery can happen anytime,  ^7Stay safe everyone!",
    ['priority_call'] = "^8^*WARNING: ^r^1A priority call was just conducted. ^3All civilians must wait ^*%s minutes ^r ^3 before conducting another one. ^7Failure to abide by this rule will lead to you being ^1comserv."
}